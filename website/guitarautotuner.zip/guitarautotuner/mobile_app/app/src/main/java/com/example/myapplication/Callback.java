package com.example.myapplication;

public interface Callback {
    void onBufferAvailable(byte[] buffer);
}
